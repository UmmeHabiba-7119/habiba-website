---
title: "Publications"
---

# Publications

This page highlights my scholarly publications and ongoing academic research. My research primarily focuses on Artificial Intelligence, Deep Learning, Computer Vision, and Remote Sensing, with applications in agriculture, environmental monitoring, and healthcare.

---

# Journal Articles

## 2026

### Image-Based Detection Framework of Freshwater Fish Disease Using Deep Learning

**Authors**

Umme Habiba, *et al.*

**Research Area**

Deep Learning • Computer Vision • Image Classification

**Summary**

This study presents a deep learning-based framework for automated freshwater fish disease detection using convolutional neural networks. Multiple pre-trained models were evaluated to identify the most effective architecture for accurate disease classification.

**Links**

- 🔗 <a href="https://scholar.google.com/citations?view_op=view_citation&hl=en&user=PELdJv8AAAAJ&citation_for_view=PELdJv8AAAAJ:u5HHmVD_uO8C" target="_blank">Google Scholar</a>

---

# Conference Papers

Currently, I have no conference publications.

---

# Ongoing Research

## Video-Based Goat Pregnancy Detection and Pregnancy Stage Estimation

**Status:** Ongoing (M.Sc. Research)

This research aims to develop an intelligent computer vision system capable of automatically detecting pregnant goats, estimating pregnancy stages, and continuously monitoring livestock through video analysis.

---

## Satellite-Based Green Cover Change and Temperature Prediction

**Status:** Ongoing

This research investigates vegetation dynamics and land surface temperature using satellite imagery and machine learning techniques for environmental monitoring and sustainable development.

---

# Research Profiles

For an updated list of my publications and citations, please visit:

- 🔗 <a href="https://scholar.google.com/citations?user=PELdJv8AAAAJ&hl=en" target="_blank">Google Scholar</a>
- 🔗 <a href="https://github.com/UmmeHabiba-7119" target="_blank">GitHub</a>
- 🔗 <a href="https://www.linkedin.com/in/umme-habiba-8a0a3b150/" target="_blank">LinkedIn</a>