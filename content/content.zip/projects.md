---
title: "Projects"
---

# Projects

My projects focus on applying Artificial Intelligence, Machine Learning, Computer Vision, and Remote Sensing to solve practical problems in agriculture, environmental monitoring, and healthcare.

---

# 🐐 Video-Based Goat Pregnancy Detection and Monitoring

**Status:** Ongoing (M.Sc. Research)

**Research Area:** Deep Learning • Computer Vision • Video Analytics

**Technologies:** Python • OpenCV • Deep Learning • Object Detection

### Overview

This research aims to develop an intelligent video-based system capable of automatically identifying pregnant goats, estimating pregnancy stages, and continuously monitoring animal health through computer vision techniques.

### Key Objectives

- Detect individual goats from video
- Identify pregnant goats
- Estimate pregnancy stage
- Monitor behaviour continuously
- Develop an AI-assisted livestock monitoring framework

---

# 🌿 Satellite-Based Green Cover and Temperature Analysis

**Status:** Ongoing

**Research Area:** Remote Sensing • Machine Learning

**Technologies:** Google Earth Engine • Python • Landsat • GIS

### Overview

This project investigates vegetation dynamics and land surface temperature using satellite imagery and machine learning techniques for environmental monitoring.

### Key Objectives

- NDVI Analysis
- Land Surface Temperature Estimation
- Green Cover Change Detection
- Temperature Prediction
- Environmental Trend Analysis

---

# 🐟 Freshwater Fish Disease Detection

**Status:** Published

**Research Area:** Deep Learning • Image Classification

**Technologies:** TensorFlow • CNN • Python

### Overview

Developed an image-based disease detection framework for freshwater fish using multiple deep learning architectures.

### Models Evaluated

- VGG16
- VGG19
- InceptionV3
- DenseNet
- MobileNet

### Publication

<a href="https://scholar.google.com/citations?view_op=view_citation&hl=en&user=PELdJv8AAAAJ&citation_for_view=PELdJv8AAAAJ:u5HHmVD_uO8C" target="_blank">
View Publication
</a>

---

# 💻 Personal Academic Portfolio Website

**Status:** Completed

**Project Type:** Personal Website

**Technologies:** Hugo • PaperMod • GitHub Pages

### Overview

Designed and developed a responsive academic portfolio website to showcase teaching, research, publications, projects, and professional achievements.

### Links

<a href="https://ummehabiba-7119.github.io/habiba-website/" target="_blank">
Live Website
</a>

&nbsp;&nbsp;|&nbsp;&nbsp;

<a href="https://github.com/UmmeHabiba-7119/habiba-website" target="_blank">
GitHub Repository
</a>